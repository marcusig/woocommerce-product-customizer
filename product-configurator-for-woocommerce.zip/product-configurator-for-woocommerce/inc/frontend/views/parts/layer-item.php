<?php if (!defined('ABSPATH')) exit; ?>
<script type="text/html" id="tmpl-mkl-pc-configurator-layer-item">
	<button class="layer-item" type="button">
		<?php do_action( 'tmpl-mkl-pc-configurator-layer-item-button' ); ?>
	</button>
</script>
