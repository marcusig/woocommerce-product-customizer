<script type="text/html" id="tmpl-mkl-pc-configurator">
	<div class="overlay"></div>
	<div class="mkl_pc_container">
		<div class="mkl_pc_bg" style="background-image: url({{data.bg_image}}); "></div>
	</div>
	<div class="loader">
		<div class="header"><?php _e( 'Loading Data', MKL_PC_DOMAIN ); ?> </div>
		<div class="spinner"></div>
	</div>
</script>
