<?php if (!defined('ABSPATH')) exit; ?>
<script type="text/html" id="tmpl-mkl-pc-configurator">
	<?php do_action( 'mkl_pc_frontend_configurator__main_view' ); ?>
</script>
