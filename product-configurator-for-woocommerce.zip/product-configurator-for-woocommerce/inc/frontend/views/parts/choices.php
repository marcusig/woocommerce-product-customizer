<?php if (!defined('ABSPATH')) exit; ?>
<script type="text/html" id="tmpl-mkl-pc-configurator-choices"> 
	<li class="layer-choices-title"><span>{{data.name}} <a href="#" class="close"><span><?php _e('Close') ?></span></a></span></li>
	<li class="choices-list"><ul>
		
	</ul></li>
</script>