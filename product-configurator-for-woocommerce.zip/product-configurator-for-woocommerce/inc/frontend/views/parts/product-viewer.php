<script type="text/html" id="tmpl-mkl-pc-configurator-viewer">
	<div class="mkl_pc_layers">
	</div>
</script>
<script type="text/html" id="tmpl-mkl-pc-configurator-angles-list">
	<a href="#"><span><?php _e( 'Change angle', MKL_PC_DOMAIN ) ?></span></a>
	<ul>
		
	</ul>
</script>

<script type="text/html" id="tmpl-mkl-pc-configurator-empty-viewer">
	<?php do_action( 'mkl_pc_templates_empty_viewer' ); ?> 
</script>
