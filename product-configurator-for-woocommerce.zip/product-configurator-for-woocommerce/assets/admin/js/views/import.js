var PC = PC || {};
PC.views = PC.views || {};


PC.views.import = Backbone.View.extend({
	initialize: function() {
		console.log('View Import');
	},
	render: function() {

	},
});

