PC.products = Backbone.Collection.extend({
	model: PC.product,
	initialize: function() {
		
	},
	on_structure_change: function() {
		
	}
});